# Polymarket Statistics Report

Based on created/reflected time.

This document aggregates public Polymarket data.
Creation time uses the original createdAt, and reflection time uses the latest collected_at_utc per id.
It intentionally avoids internal storage/implementation details.

## Series

- Total unique count: **1,372**
- Created time range: 2022-10-13 00:34:06.557000+00:00 ~ 2026-03-27 20:01:19.039000+00:00
- Latest reflected time range: 2026-03-30 00:08:53.471000+00:00 ~ 2026-03-30 00:10:30.606000+00:00

## Event

- Total unique count: **312,762**
- Created time range: 2022-07-27 14:40:02.074000+00:00 ~ 2026-03-29 23:52:06.809000+00:00
- Latest reflected time range: 2026-02-17 19:39:34.045000+00:00 ~ 2026-03-30 00:01:18.985000+00:00

## Market

- Total unique count: **757,440**
- Created time range: 2020-10-02 16:10:01.467000+00:00 ~ 2026-03-30 00:00:28.374000+00:00
- Latest reflected time range: 2026-02-28 10:01:20.607000+00:00 ~ 2026-03-30 00:08:44.807000+00:00

### Series / Created time / Yearly

![](charts/series_created_yearly.png)

Top buckets:
  - 2025: 728
  - 2026: 623
  - 2023: 12
  - 2022: 5
  - 2024: 4

### Series / Latest reflected time / Yearly

![](charts/series_collected_yearly.png)

Top buckets:
  - 2026: 1,372

### Series / Created time / Monthly

![](charts/series_created_monthly.png)

Top buckets:
  - 2026-01: 231
  - 2025-11: 209
  - 2026-03: 201
  - 2026-02: 191
  - 2025-10: 146

### Series / Latest reflected time / Monthly

![](charts/series_collected_monthly.png)

Top buckets:
  - 2026-03: 1,372

### Series / Created time / Daily

![](charts/series_created_daily.png)

Top buckets:
  - 2025-11-05: 70
  - 2026-01-31: 52
  - 2025-11-11: 41
  - 2026-03-26: 39
  - 2026-02-03: 34

### Series / Latest reflected time / Daily

![](charts/series_collected_daily.png)

Top buckets:
  - 2026-03-30: 1,372

### Series / Created time / Hourly

![](charts/series_created_hourly.png)

Top buckets:
  - 2025-11-05 20:00: 43
  - 2026-03-26 22:00: 36
  - 2026-01-31 21:00: 30
  - 2026-03-20 20:00: 28
  - 2026-02-03 16:00: 27

### Series / Latest reflected time / Hourly

![](charts/series_collected_hourly.png)

Top buckets:
  - 2026-03-30 00:00: 1,372

### Event / Created time / Yearly

![](charts/event_created_yearly.png)

Top buckets:
  - 2026: 186,074
  - 2025: 116,169
  - 2024: 5,912
  - 2022: 3,171
  - 2023: 1,436

### Event / Latest reflected time / Yearly

![](charts/event_collected_yearly.png)

Top buckets:
  - 2026: 312,762

### Event / Created time / Monthly

![](charts/event_created_monthly.png)

Top buckets:
  - 2026-03: 85,069
  - 2026-01: 58,354
  - 2026-02: 42,651
  - 2025-12: 40,802
  - 2025-11: 23,997

### Event / Latest reflected time / Monthly

![](charts/event_collected_monthly.png)

Top buckets:
  - 2026-03: 312,761
  - 2026-02: 1

### Event / Created time / Daily

![](charts/event_created_daily.png)

Top buckets:
  - 2026-03-14: 3,802
  - 2026-03-28: 3,801
  - 2026-03-29: 3,786
  - 2026-03-27: 3,717
  - 2026-03-26: 3,662

### Event / Latest reflected time / Daily

![](charts/event_collected_daily.png)

Top buckets:
  - 2026-03-02: 216,000
  - 2026-03-29: 21,445
  - 2026-03-30: 8,413
  - 2026-03-27: 3,515
  - 2026-03-17: 3,317

### Event / Created time / Hourly

![](charts/event_created_hourly.png)

Top buckets:
  - 2022-07-27 14:00: 2,801
  - 2025-06-28 20:00: 639
  - 2025-10-29 22:00: 527
  - 2026-01-28 15:00: 424
  - 2025-12-17 21:00: 396

### Event / Latest reflected time / Hourly

![](charts/event_collected_hourly.png)

Top buckets:
  - 2026-03-02 15:00: 215,276
  - 2026-03-29 23:00: 18,534
  - 2026-03-30 00:00: 8,413
  - 2026-03-08 07:00: 713
  - 2026-03-07 23:00: 711

### Market / Created time / Yearly

![](charts/market_created_yearly.png)

Top buckets:
  - 2026: 456,487
  - 2025: 265,590
  - 2024: 22,515
  - 2022: 6,068
  - 2023: 4,861

### Market / Latest reflected time / Yearly

![](charts/market_collected_yearly.png)

Top buckets:
  - 2026: 757,440

### Market / Created time / Monthly

![](charts/market_created_monthly.png)

Top buckets:
  - 2026-03: 200,975
  - 2026-01: 131,872
  - 2026-02: 123,640
  - 2025-12: 79,776
  - 2025-11: 50,021

### Market / Latest reflected time / Monthly

![](charts/market_collected_monthly.png)

Top buckets:
  - 2026-03: 729,005
  - 2026-02: 28,435

### Market / Created time / Daily

![](charts/market_created_daily.png)

Top buckets:
  - 2026-03-29: 10,787
  - 2026-03-28: 10,303
  - 2026-03-24: 9,040
  - 2026-03-16: 9,029
  - 2026-03-27: 8,535

### Market / Latest reflected time / Daily

![](charts/market_collected_daily.png)

Top buckets:
  - 2026-03-02: 493,407
  - 2026-03-30: 33,757
  - 2026-02-28: 28,435
  - 2026-03-29: 28,271
  - 2026-03-09: 9,659

### Market / Created time / Hourly

![](charts/market_created_hourly.png)

Top buckets:
  - 2026-01-28 15:00: 2,833
  - 2022-07-27 14:00: 2,799
  - 2026-02-27 19:00: 2,197
  - 2026-03-29 18:00: 2,144
  - 2026-03-09 16:00: 2,026

### Market / Latest reflected time / Hourly

![](charts/market_collected_hourly.png)

Top buckets:
  - 2026-03-02 15:00: 491,044
  - 2026-03-30 00:00: 33,757
  - 2026-03-29 23:00: 14,403
  - 2026-02-28 19:00: 7,402
  - 2026-02-28 10:00: 6,268

